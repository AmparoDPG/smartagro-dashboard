SMARTAGRO – PANEL DE CONTROL AGRÍCOLA

REQUISITOS:
- Tener Python instalado (https://www.python.org/downloads/)
- Tener conexión a internet

INSTRUCCIONES:
1. Abre la carpeta SmartAgroApp
2. Haz doble clic en el archivo "lanzar.bat"
3. Espera unos segundos
4. Tu navegador se abrirá con la aplicación SmartAgro

SI ES LA PRIMERA VEZ:
1. Abre una terminal en esta carpeta
2. Escribe:
   pip install -r requirements.txt
3. Luego ejecuta "lanzar.bat"

---

Si no se abre automáticamente, ve manualmente a:
http://localhost:8501